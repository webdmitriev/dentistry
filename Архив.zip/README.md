# www

---

## 🚀 Возможности

- Frontend

## 🛠 Технологии

- HTML, JS, SCSS
- Animations

## 📸 Скриншоты

| Home                                                                                  |
| ------------------------------------------------------------------------------------- |
| ![Onboarding](https://api.webdmitriev.com/wp-content/uploads/2025/10/nz-overseas.png) |

## ⚙️ Установка

1. Клонируйте репозиторий:

```bash
git clone https://github.com/webdmitriev/nz-overseas
```
